/* SmartCare Careers - lightweight client-side validation
 * Server-side validation is the source of truth (see careers/includes/helpers.php).
 */

(function () {
  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function normalizePhone(v) {
    return String(v || '').replace(/[^0-9]/g, '');
  }

  function isUkMobile(v) {
    var p = normalizePhone(v);
    return /^07\d{9}$/.test(p);
  }

  function isUkPhone(v) {
    var p = normalizePhone(v);
    return /^0\d{9,10}$/.test(p);
  }

  function normalizePostcode(pc) {
    pc = String(pc || '').toUpperCase().trim().replace(/\s+/g, '');
    if (pc.length > 3) pc = pc.slice(0, -3) + ' ' + pc.slice(-3);
    return pc.trim();
  }

  function isUkPostcode(pc) {
    pc = normalizePostcode(pc);
    return /^(GIR 0AA|(?:[A-Z]{1,2}\d{1,2}[A-Z]?)\s*\d[A-Z]{2})$/i.test(pc);
  }

  function isEmail(v) {
    v = String(v || '').trim();
    if (!v) return false;
    // simple, pragmatic check
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
  }

  function setFieldError(field, message) {
    if (!field) return;
    field.setAttribute('aria-invalid', 'true');
    field.classList.add('border-red-300');
    var id = field.getAttribute('id');
    if (!id) {
      id = 'sc_field_' + Math.random().toString(16).slice(2);
      field.setAttribute('id', id);
    }

    var existing = field.parentNode ? field.parentNode.querySelector('[data-sc-error-for="' + id + '"]') : null;
    if (existing) existing.remove();

    var p = document.createElement('p');
    p.setAttribute('data-sc-error-for', id);
    p.className = 'mt-1 text-[10px] text-red-600';
    p.textContent = message;
    if (field.parentNode) field.parentNode.appendChild(p);
  }

  function clearFieldError(field) {
    if (!field) return;
    field.removeAttribute('aria-invalid');
    field.classList.remove('border-red-300');
    var id = field.getAttribute('id');
    if (!id || !field.parentNode) return;
    var existing = field.parentNode.querySelector('[data-sc-error-for="' + id + '"]');
    if (existing) existing.remove();
  }

  function showTopError(form, messages) {
    var box = qs('#sc-client-errors', form);
    if (box) box.remove();
    if (!messages.length) return;

    box = document.createElement('div');
    box.id = 'sc-client-errors';
    box.className = 'rounded-2xl border border-red-200 bg-red-50 px-4 py-3';

    var title = document.createElement('p');
    title.className = 'text-xs font-semibold text-slate-900';
    title.textContent = 'Please fix the following:';
    box.appendChild(title);

    var ul = document.createElement('ul');
    ul.className = 'mt-2 list-disc pl-5 space-y-1 text-[11px] text-slate-700';
    messages.forEach(function (m) {
      var li = document.createElement('li');
      li.textContent = m;
      ul.appendChild(li);
    });
    box.appendChild(ul);

    form.insertBefore(box, form.firstChild);
  }

  function validateStep1(form) {
    var messages = [];

    var first = qs('input[name="first_name"]', form);
    var last  = qs('input[name="last_name"]', form);
    var dob   = qs('input[name="dob"]', form);
    var email = qs('input[name="email"]', form);
    var phone = qs('input[name="phone"]', form);
    var line1 = qs('input[name="address_line1"]', form);
    var town  = qs('input[name="address_town"]', form);
    var pc    = qs('input[name="address_postcode"]', form);

    var pos   = qs('select[name="position_applied_for"]', form);
    var workT = qs('select[name="work_type"]', form);
    var rtw   = qs('select[name="has_right_to_work"], input[name="has_right_to_work"]', form);
    var dbs   = qs('select[name="has_current_dbs"], input[name="has_current_dbs"]', form);

    [first,last,dob,email,phone,line1,town,pc,pos,workT,rtw,dbs].forEach(clearFieldError);

    function req(field, label) {
      if (!field || !String(field.value || '').trim()) {
        setFieldError(field, label + ' is required.');
        messages.push(label + ' is required.');
        return false;
      }
      return true;
    }

    req(first, 'First name');
    req(last, 'Last name');
    req(dob, 'Date of birth');

    if (req(email, 'Email') && !isEmail(email.value)) {
      setFieldError(email, 'Please enter a valid email address.');
      messages.push('Email must be valid.');
    }

    if (req(phone, 'Mobile number') && !isUkMobile(phone.value)) {
      setFieldError(phone, 'Use UK mobile format 07XXXXXXXXX (no +44).');
      messages.push('Mobile number must be UK format 07XXXXXXXXX.');
    }

    req(line1, 'Address line 1');
    req(town, 'Town / City');

    if (req(pc, 'Postcode')) {
      if (!isUkPostcode(pc.value)) {
        setFieldError(pc, 'Please enter a valid UK postcode (e.g. KT2 6PT).');
        messages.push('Postcode must be a valid UK postcode.');
      } else {
        pc.value = normalizePostcode(pc.value);
      }
    }

    req(pos, 'Position applied for');
    req(workT, 'Work type');
    req(rtw, 'Right to work');
    req(dbs, 'DBS status');

    showTopError(form, messages);
    return messages.length === 0;
  }

  function validateStep6(form) {
    var messages = [];
    var checks = [
      qs('input[name="confirm_true_information"]', form),
      qs('input[name="aware_of_false_info_consequences"]', form),
      qs('input[name="consent_to_processing"]', form)
    ];
    var sig = qs('input[name="typed_signature"]', form);
    var date = qs('input[name="signature_date"]', form);

    checks.forEach(clearFieldError);
    clearFieldError(sig);
    clearFieldError(date);

    checks.forEach(function (c, idx) {
      if (c && !c.checked) {
        setFieldError(c, 'Please tick this declaration.');
        messages.push('Please tick all declarations.');
      }
    });

    if (!sig || !String(sig.value || '').trim()) {
      setFieldError(sig, 'Please type your full name.');
      messages.push('Typed signature is required.');
    }

    if (!date || !String(date.value || '').trim()) {
      setFieldError(date, 'Please provide the signature date.');
      messages.push('Signature date is required.');
    }

    showTopError(form, messages);
    return messages.length === 0;
  }

  function attach() {
    var form = qs('form[action*="careers/apply.php"], form[action*="apply.php"]');
    if (!form) return;

    var stepEl = qs('input[name="step"]', form);
    var step = stepEl ? parseInt(stepEl.value, 10) : 0;

    form.addEventListener('submit', function (e) {
      var ok = true;
      if (step === 1) ok = validateStep1(form);
      if (step === 6) ok = validateStep6(form);
      if (!ok) e.preventDefault();
    });

    // Normalize UK postcode on blur
    var pc = qs('input[name="address_postcode"]', form);
    if (pc) {
      pc.addEventListener('blur', function () {
        if (String(pc.value || '').trim()) pc.value = normalizePostcode(pc.value);
      });
    }

    // Normalize phones on blur
    qsa('input[type="tel"]', form).forEach(function (p) {
      p.addEventListener('blur', function () {
        var raw = String(p.value || '').trim();
        if (!raw) return;
        // keep user's formatting visually, but strip double spaces
        p.value = raw.replace(/\s+/g, ' ');
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attach);
  } else {
    attach();
  }
})();
