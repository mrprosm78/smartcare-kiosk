<?php
require __DIR__ . '/db.php';

echo "DB OK";