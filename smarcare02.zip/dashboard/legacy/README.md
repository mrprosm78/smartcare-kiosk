# Legacy dashboard pages

This folder contains legacy/unused dashboard pages preserved temporarily for reference.

**Do not link to these pages from the UI.**

Once all environments are confirmed migrated, these files can be deleted.
