# SmartCare Admin UI Prototype (Static)

Open `index.html` (or `dashboard.html`) in your browser.

- Tailwind is loaded via CDN.
- Light background, full-screen layout.
- Low rounding + low padding, table-first UI.
- Static slide-over panel visible on large screens to show the intended "details in same page" UX.

Pages:
- dashboard.html
- shifts.html
- punch-details.html
- employees.html
- payroll.html
- reports.html
- settings.html
