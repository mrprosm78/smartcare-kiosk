<!-- Add this button near the top of admin/shifts.php header -->
<a href="/kiosk-dev/admin/shift-editor.php"
   class="inline-flex items-center rounded bg-indigo-600 px-3 py-2 text-sm text-white">
  Edit Shifts
</a>
