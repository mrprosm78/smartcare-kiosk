<?php
require __DIR__ . '/router.php';
