<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

session_start();

$step = isset($_POST['_step']) ? (int)$_POST['_step'] : 1;
if ($step < 1) $step = 1;
if ($step > 3) $step = 3;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['application'][$step] = $_POST;

    if ($step < 3) {
        header('Location: apply.php');
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO kiosk_applications 
        (full_name, email, phone, payload_json, created_at)
        VALUES (?, ?, ?, ?, UTC_TIMESTAMP())");

    $payload = json_encode($_SESSION['application'], JSON_THROW_ON_ERROR);

    $stmt->execute([
        $_POST['full_name'] ?? '',
        $_POST['email'] ?? '',
        $_POST['phone'] ?? '',
        $payload
    ]);

    unset($_SESSION['application']);
    echo "<h2>Application submitted successfully</h2>";
    exit;
}
?>
<!doctype html>
<html>
<body>
<form method="post">
<input type="hidden" name="_step" value="<?= $step+1 ?>">
<?php if ($step === 1): ?>
  <h3>Step 1 – Personal</h3>
  <input name="full_name" placeholder="Full name" required>
  <input name="email" placeholder="Email" required>
<?php elseif ($step === 2): ?>
  <h3>Step 2 – Contact</h3>
  <input name="phone" placeholder="Phone" required>
<?php else: ?>
  <h3>Step 3 – Confirm</h3>
  <button type="submit">Submit</button>
<?php endif; ?>
<?php if ($step < 3): ?>
<button type="submit">Next</button>
<?php endif; ?>
</form>
</body>
</html>
