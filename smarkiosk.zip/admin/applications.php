<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';
admin_require_login($pdo);

$rows = $pdo->query("SELECT * FROM kiosk_applications ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<h1>Applications</h1>
<table border="1">
<tr><th>Name</th><th>Email</th><th>Created</th></tr>
<?php foreach ($rows as $r): ?>
<tr>
<td><?= htmlspecialchars($r['full_name']) ?></td>
<td><?= htmlspecialchars($r['email']) ?></td>
<td><?= $r['created_at'] ?></td>
</tr>
<?php endforeach; ?>
</table>
